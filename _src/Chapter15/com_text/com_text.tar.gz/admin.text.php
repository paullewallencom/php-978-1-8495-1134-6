<?php

/**
*
* This the Text Component, designed to be installed into Aliro to store straightforward articles that do not need to be in folders, or use access control or anything fancy.
*
* Copyright in this edition belongs to Martin Brampton
* Email - counterpoint@aliro.org
* Web - http://www.aliro.org
*
* Information about Aliro can be found at http://www.aliro.org
*
*/

// This is the manager that takes control and analyses what needs to be done
// If nothing special is needed, the class can be empty, relying entirely on the parent class
class textAdmin extends aliroComponentAdminManager  {

	// This could be omitted - included here in case extra code needs to be added
	public function __construct ($component, $system, $version) {
		parent::__construct ($component, $system, $version);
	}

	// Likewise, this could be omitted unless extra code is needed
	public function activate () {
		parent::activate();
	}

}

